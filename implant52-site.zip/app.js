(() => {
 'use strict';
 const publicPath=new URL('.',document.currentScript.src).pathname;
 const pageUrl=url=>url.startsWith('/') ? publicPath+url.slice(1) : url;
 const names={all:'Обе клиники',str:'Страж Революции, 24А',kaz:'Казанская набережная, 5'};
 const phones={all:['+78312601200','+7 (831) 260-12-00'],str:['+78312601220','+7 (831) 260-12-20'],kaz:['+78312601200','+7 (831) 260-12-00']};
 const normalize=s=>s.toLocaleLowerCase('ru').replace(/ё/g,'е').trim();
 let branch='all';try{branch=localStorage.getItem('implant52-preview-branch')||'all'}catch{}
 const requestedBranch=new URLSearchParams(location.search).get('branch') ?? document.querySelector('[data-page-branch]')?.dataset.pageBranch;
 if(Object.hasOwn(names,requestedBranch))branch=requestedBranch;
 const serviceBranchGroups=document.querySelectorAll('[data-service-branch]');
 let closeToast;
 const picker=document.querySelector('#clinic-picker');
 const branchOptions=[...document.querySelectorAll('[data-branch-option]')];

 function setBranch(value,announce=false){
  branch=Object.hasOwn(names,value)?value:'all';
  document.querySelectorAll('[data-branch]').forEach(select=>select.value=branch);
  branchOptions.forEach(option=>option.checked=option.value===branch);
  document.querySelectorAll('[data-branch-label]').forEach(label=>label.textContent=branch==='all'?'Выбрать клинику':names[branch]);
  document.querySelectorAll('[data-branch-card]').forEach(card=>card.classList.toggle('selected',card.dataset.branchCard===branch));
  document.querySelectorAll('[data-clinic-phone]').forEach(link=>{
   link.href='tel:'+phones[branch][0];
   if(link.classList.contains('phone'))link.textContent=phones[branch][1];
  });
  try{localStorage.setItem('implant52-preview-branch',branch)}catch{}
  filterDoctors();
  filterPrices();
  serviceBranchGroups.forEach(group=>{group.hidden=branch!=='all'&&group.dataset.serviceBranch!==branch});
  if(announce){
   const toast=document.querySelector('.branch-toast');
   toast.textContent=branch==='all'?'Показываем обе клиники':'Выбран адрес: '+names[branch];
   toast.hidden=false;
   clearTimeout(closeToast);
   closeToast=setTimeout(()=>toast.hidden=true,4000);
  }
 }
 document.querySelectorAll('[data-branch]').forEach(select=>select.addEventListener('change',()=>setBranch(select.value)));
 branchOptions.forEach(option=>option.addEventListener('change',()=>setBranch(option.value,true)));
 document.querySelectorAll('[data-pick-branch]').forEach(button=>button.addEventListener('click',()=>setBranch(button.dataset.pickBranch,true)));

 const menu=document.querySelector('.menu-toggle'),nav=document.querySelector('#main-nav');
 function showMenu(open){
  menu.setAttribute('aria-expanded',String(open));
  menu.setAttribute('aria-label',open?'Закрыть меню':'Открыть меню');
  nav.classList.toggle('is-open',open);
 }
 menu?.addEventListener('click',()=>{
  if(picker)picker.open=false;
  showMenu(menu.getAttribute('aria-expanded')!=='true');
 });
 picker?.addEventListener('toggle',()=>{if(picker.open&&menu)showMenu(false);});
 picker?.addEventListener('keydown',event=>{
  if(event.key!=='Escape'||!picker.open)return;
  picker.open=false;
  picker.querySelector('summary').focus();
 });
 document.addEventListener('click',event=>{if(picker?.open&&!picker.contains(event.target))picker.open=false;});
 nav?.addEventListener('keydown',event=>{if(event.key==='Escape'){showMenu(false);menu.focus();}});
 document.querySelectorAll('[role=tablist]').forEach(group=>{const tabs=[...group.querySelectorAll('[role=tab]')];const activate=t=>{tabs.forEach(x=>{x.setAttribute('aria-selected',String(x===t));x.tabIndex=x===t?0:-1;const panel=document.getElementById(x.dataset.panel);if(panel)panel.hidden=x!==t})};tabs.forEach((t,i)=>{t.tabIndex=t.getAttribute('aria-selected')==='true'?0:-1;t.addEventListener('click',()=>activate(t));t.addEventListener('keydown',e=>{let j=i;if(e.key==='ArrowRight')j=(i+1)%tabs.length;else if(e.key==='ArrowLeft')j=(i+tabs.length-1)%tabs.length;else if(e.key==='Home')j=0;else if(e.key==='End')j=tabs.length-1;else return;e.preventDefault();activate(tabs[j]);tabs[j].focus()})})});
 document.querySelectorAll('.compare input').forEach(r=>r.addEventListener('input',()=>r.closest('.compare').style.setProperty('--split',r.value+'%')));
 const doctorSearch=document.querySelector('#doctor-search'),specialty=document.querySelector('#doctor-specialty');
 function filterDoctors(){if(!doctorSearch)return;const q=normalize(doctorSearch.value),spec=specialty.value;let n=0;document.querySelectorAll('[data-doctor-card]').forEach(c=>{const ok=normalize(c.textContent).includes(q)&&(spec==='all'||c.dataset.specialty.split(' ').includes(spec))&&(branch==='all'||c.dataset.branches.split(' ').includes(branch));c.hidden=!ok;if(ok)n++});document.querySelector('#doctor-count').textContent='Специалистов: '+n;document.querySelector('#doctor-empty').hidden=n>0}
 doctorSearch?.addEventListener('input',filterDoctors);specialty?.addEventListener('change',filterDoctors);document.querySelector('[data-reset-doctors]')?.addEventListener('click',()=>{doctorSearch.value='';specialty.value='all';setBranch('all')});
 const priceSearch=document.querySelector('#price-search'),priceGroup=document.querySelector('#price-group');
 function filterPrices(){if(!priceSearch)return;let n=0;const q=normalize(priceSearch.value),g=priceGroup.value;document.querySelectorAll('[data-price-row]').forEach(r=>{r.hidden=!(normalize(r.textContent).includes(q)&&(g==='all'||r.dataset.priceGroup===g)&&(branch==='all'||r.dataset.priceBranch===branch));if(!r.hidden)n++});document.querySelector('#price-count').textContent='Ценовых позиций: '+n;document.querySelector('#price-empty').hidden=n>0}
 priceSearch?.addEventListener('input',filterPrices);priceGroup?.addEventListener('change',filterPrices);
 const serviceSearch=document.querySelector('#service-search');serviceSearch?.addEventListener('input',filterServices);function filterServices(){if(!serviceSearch)return;let n=0;const q=normalize(serviceSearch.value);document.querySelectorAll('[data-service-group]').forEach(g=>{let group=0;g.querySelectorAll('[data-service-item]').forEach(e=>{e.hidden=!normalize(e.textContent).includes(q);if(!e.hidden){n++;group++}});g.hidden=group===0});document.querySelector('#service-count').textContent='Услуг в подразделах: '+n;document.querySelector('#service-empty').hidden=n>0}filterServices();
 document.querySelectorAll('[data-case-filter]').forEach(b=>b.addEventListener('click',()=>{let n=0;document.querySelectorAll('[data-case-filter]').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',String(x===b))});document.querySelectorAll('[data-case-category]').forEach(c=>{c.hidden=b.dataset.caseFilter!=='all'&&c.dataset.caseCategory!==b.dataset.caseFilter;if(!c.hidden)n++});const count=document.querySelector('#case-count');if(count)count.textContent='Работ: '+n}));document.querySelector('[data-case-filter="all"]')?.click();
 let lastFocus=null;document.querySelectorAll('dialog').forEach(d=>{d.querySelector('.dialog-close')?.addEventListener('click',()=>d.close());d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close()}});d.addEventListener('close',()=>lastFocus?.focus())});
 const modal=document.querySelector('#booking'),bs=document.querySelector('#booking-service'),bb=document.querySelector('#booking-branch'),bd=document.querySelector('#booking-doctor');
 const doctorLabel=document.querySelector('#booking-doctor-label');
 const bookingPhone=modal.querySelector('[data-clinic-phone]');
 function updateBookingPhone(){bookingPhone.href='tel:'+phones[bb.value][0]}
 function setBookingDoctor(doctor, availableBranches){
  bd.value=doctor;
  doctorLabel.hidden=!doctor;
  for(const option of bb.options){
   option.disabled=availableBranches.length>0&&option.value!=='all'&&!availableBranches.includes(option.value);
  }
 }
 document.querySelectorAll('[data-book]').forEach(button=>button.addEventListener('click',()=>{
  lastFocus=button;
  
  const service=button.dataset.service||'consult';
  const contextOption=bs.querySelector('[data-context]');
  contextOption?.remove();
  if(![...bs.options].some(option=>option.value===service)){
   const option=new Option(button.dataset.serviceLabel||service,service);
   option.dataset.context='1';
   bs.append(option);
  }
  bs.value=service;
  const availableBranches=button.dataset.doctorBranches?.split(' ')??[];
  setBookingDoctor(button.dataset.doctor||'',availableBranches);
  const preferred=Object.hasOwn(names,button.dataset.bookBranch)?button.dataset.bookBranch:branch;
  if(availableBranches.length===1){
   bb.value=availableBranches[0];
  }else{
   bb.value=[...bb.options].some(option=>option.value===preferred&&!option.disabled)?preferred:'all';
  }
  updateBookingPhone();
  modal.showModal();
 }));
 bb.addEventListener('change',updateBookingPhone);
 bs.addEventListener('change',()=>setBookingDoctor('',[]));
 let searchData;async function getSearch(){if(!searchData)searchData=fetch(pageUrl('/search-index.json')).then(r=>{if(!r.ok)throw Error();return r.json()});return searchData}
 function renderSearch(input){const box=input.closest('section,.dialog-inner'),out=box.querySelector('[data-search-results]'),count=box.querySelector('[data-search-count]'),q=normalize(input.value);if(!q){out.replaceChildren();count.textContent='Введите название услуги, имя врача или вопрос.';return}getSearch().then(data=>{const terms=q.split(/\s+/);if(normalize(input.value)!==q)return;const titleMatches=data.filter(x=>terms.every(t=>normalize(x.title).includes(t.length>5?t.slice(0,-2):t)));const found=titleMatches.length?titleMatches:data.filter(x=>terms.every(t=>normalize(x.title+' '+x.description).includes(t)));found.sort((a,b)=>Number(normalize(b.title).includes(q))-Number(normalize(a.title).includes(q)));out.replaceChildren();count.textContent=found.length?'Найдено страниц: '+found.length:'Совпадений нет. Попробуйте другой запрос.';for(const x of found.slice(0,30)){const a=document.createElement('a');a.className='search-result';a.href=pageUrl(x.url);const h=document.createElement('strong');h.textContent=x.title;const p=document.createElement('p');p.textContent=x.description;a.append(h,p);out.append(a)}}).catch(()=>{count.textContent='Поиск временно недоступен. Откройте каталог услуг.'})}
 document.querySelectorAll('#global-search,#page-search').forEach(i=>{i.addEventListener('input',()=>renderSearch(i));renderSearch(i)});document.querySelector('[data-search-open]')?.addEventListener('click',e=>{lastFocus=e.currentTarget;document.querySelector('#site-search').showModal();document.querySelector('#global-search').focus()});
 document.querySelectorAll('[data-review-widget]').forEach(b=>b.addEventListener('click',()=>{const frame=document.createElement('iframe');frame.src='https://yandex.ru/maps-reviews-widget/'+b.dataset.reviewWidget+'?comments';frame.title='Отзывы о клинике на Яндекс Картах';frame.width='100%';frame.height='600';frame.loading='lazy';frame.style.border='0';b.closest('.review-widget').replaceChildren(frame)}));setBranch(branch);
 const datedOffers = document.querySelectorAll('[data-offer-expiry]');
 if(datedOffers.length){
  const today = new Intl.DateTimeFormat('sv-SE',{timeZone:'Europe/Moscow'}).format(new Date());
  const archive = document.querySelector('[data-offer-archive]');
  for(const offer of datedOffers){
   if(offer.dataset.offerExpiry>=today)continue;
   offer.querySelector('[data-offer-date]').textContent='Срок завершился';
   if(offer.matches('article')&&archive){
    archive.hidden=false;
    archive.querySelector('.offer-grid').append(offer);
   }else{
    document.querySelector('[data-offer-booking]').hidden=true;
    document.querySelector('[data-offer-return]').hidden=false;
   }
  }
 }
 document.querySelectorAll('[data-tour-src]').forEach(button=>button.addEventListener('click',()=>{
  const frame = document.createElement('iframe');
  frame.src=button.dataset.tourSrc;
  frame.title='Виртуальная прогулка по клинике';
  frame.referrerPolicy='no-referrer';
  frame.allowFullscreen=true;
  button.closest('[data-tour-container]').replaceChildren(frame);
  frame.focus();
 }));

 const helper = document.querySelector('[data-slavik]');
 if(helper){
  const launch = helper.querySelector('.slavik-launch');
  const panel = helper.querySelector('.slavik-panel');
  const close = helper.querySelector('[data-slavik-close]');
  const form = helper.querySelector('.slavik-form');
  const field = form.elements.question;
  const reply = helper.querySelector('.slavik-reply');
  const clinicPaths = {str:'/clinics/strazh-revolyutsii/',kaz:'/clinics/kazanskaya-naberezhnaya/'};
  let questionId = 0;

  function toggleHelper(open){
   panel.hidden=!open;
   launch.setAttribute('aria-expanded',String(open));
   (open?close:launch).focus();
  }

  function renderAnswer(text, links=[]){
   const paragraph=document.createElement('p');
   paragraph.textContent=text;
   reply.replaceChildren(paragraph);
   if(links.length){
    const list=document.createElement('ul');
    for(const [label,url] of links){
     const item=document.createElement('li');
     const anchor=document.createElement('a');
     anchor.href=pageUrl(url);
     anchor.textContent=label;
     item.append(anchor);
     list.append(item);
    }
    reply.append(list);
   }
   reply.hidden=false;
  }

  const commonTopics = [
   [/дмс|страхов/, 'До визита уточните у страховщика, что покрывает полис, и согласуйте филиал с администратором.', [['Как записаться по ДМС','/patients/dms/']]],
   [/рассроч|частями|кредит/, 'Сначала запросите у врача план по этапам. Условия оплаты можно обсудить с координатором.', [['Оплата частями','/patients/installments/']]],
   [/щетк|revyline/, 'У программы «Щётка бесконечности» есть условия участия и получения следующей щётки.', [['Условия программы','/offers/shchyotka-beskonechnosti/']]],
   [/гигиен|чистк|налет|кам(ень|ня)/, 'Состав профессиональной гигиены и актуальные предложения есть на этих страницах.', [['Профессиональная гигиена','/services/gigiena-i-profilaktika/professionalnaya-gigiena/'],['Акции клиники','/offers/']]],
   [/имплан|all.on.4|all.on.6|straumann/, 'На странице имплантации собраны варианты восстановления одного зуба или целого ряда. Стоимость зависит от плана.', [['Имплантация и цены по этапам','/services/implantatsiya-i-khirurgiya/']]],
   [/ребен|детск/, 'Условия приёма детей и подходящие специалисты собраны в разделе детской стоматологии.', [['Детская стоматология','/services/detskaya-stomatologiya/']]],
   [/акци|скидк|сертификат/, 'У каждого предложения указаны условия и срок действия.', [['Акции и программы','/offers/']]],
   [/отзыв|рейтинг/, 'Отзывы доступны отдельно по каждому адресу.', [['Отзывы о двух клиниках','/reviews/']]],
  ];

  async function answer(question){
   const id=++questionId;
   const query=normalize(question);
   const mentioned=/казан/.test(query)?'kaz':/никон|революц|страж/.test(query)?'str':null;
   const preferred=mentioned||branch;
   const branchQuery=preferred==='all'?'':'?branch='+preferred;
   if(/адрес|доехать|добраться|парков|находит|режим|часы/.test(query)||/^(?:филиалы|клиники|где филиал)$/.test(query)){
    const selected = mentioned?[mentioned]:['str','kaz'];
    renderAnswer('Выберите адрес, чтобы посмотреть часы, фотографии и маршрут.',selected.map(key=>[names[key],clinicPaths[key]]));
    return;
   }
   if(/подготов|взять с собой/.test(query)){
    renderAnswer('На странице первого визита есть список документов и вопросы, которые стоит обсудить с врачом.',[['Первый визит','/patients/first-visit/']]);
    return;
   }
   if(/запис|перв(ый|ом) визит|позвон|телефон/.test(query)&&!/дмс/.test(query)){
    renderAnswer('Администратор подберёт специалиста и подтвердит время визита.',[
     ['Выбрать клинику и записаться','/patients/appointment/'+branchQuery],
     ['Позвонить '+phones[preferred][1],'tel:'+phones[preferred][0]],
    ]);
    return;
   }
   if(/цен[аыу]|стои[тм]|прайс|сколько/.test(query)&&!/гигиен|чистк|имплан|all.on./.test(query)){
    renderAnswer('В прайсе можно найти конкретную услугу и отфильтровать цены по клинике.',[['Посмотреть прайс','/prices/'+branchQuery]]);
    return;
   }
   if(/^(врачи|врач|специалисты)$|как (найти|выбрать) врача/.test(query)){
    renderAnswer('В каталоге можно выбрать направление, специалиста и удобный адрес.',[['Посмотреть врачей','/doctors/'+branchQuery]]);
    return;
   }
   const topic=commonTopics.find(([pattern])=>pattern.test(query));
   if(topic){
    renderAnswer(topic[1],topic[2]);
    return;
   }
   const terms=query.match(/[а-яa-z]{4,}/g)||[];
   const filler=new Set(['можно','подскажите','пожалуйста','какие','какой','делаете','хочу','нужно']);
   const keywords=terms.filter(term=>!filler.has(term)).map(term=>term.length>5?term.slice(0,-2):term);
   try{
    const items=await getSearch();
    if(id!==questionId)return;
    const candidates=items.map(item=>{
     const title=normalize(item.title);
     const matches=keywords.filter(word=>title.includes(word)).length;
     return [item,matches];
    }).filter(([,score])=>score>0).sort((a,b)=>b[1]-a[1]).slice(0,4);
    if(candidates.length){
     renderAnswer('Вот страницы, которые могут помочь.',candidates.map(([item])=>[item.title,item.url]));
     return;
    }
   }catch{}
   if(id!==questionId)return;
   renderAnswer('Администратор поможет уточнить нужную услугу и доступное время. Индивидуальные вопросы о лечении лучше обсудить с врачом.',[
    ['Связаться с клиникой','/patients/questions/'],
    ['Позвонить '+phones[preferred][1],'tel:'+phones[preferred][0]],
   ]);
  }

  launch.addEventListener('click',()=>toggleHelper(panel.hidden));
  close.addEventListener('click',()=>toggleHelper(false));
  helper.addEventListener('keydown',event=>{
   if(event.key==='Escape'&&!panel.hidden){event.stopPropagation();toggleHelper(false);}
  });
  helper.querySelectorAll('[data-suggest]').forEach(button=>button.addEventListener('click',()=>answer(button.dataset.suggest)));
  form.addEventListener('submit',event=>{
   event.preventDefault();
   const question=field.value.trim();
   if(question)answer(question);
  });
 }
})();
